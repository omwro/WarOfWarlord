package omwro.warofwarlord;

import java.util.Map;
import java.util.TreeMap;

class GameManager {
    private static Map<Integer, Gamemode> gameList = new TreeMap<>();

    static Map<Integer, Gamemode> getGamemodes() {
        return gameList;
    }

    static Gamemode getGamemodeByID(int id) {
        return gameList.get(id);
    }

    static Gamemode addGamemode(Gamemode gamemode) {
        return gameList.put(gamemode.getGameID(), gamemode);
    }

    static Gamemode updateGamemode(Gamemode gamemode) {
        return gameList.put(gamemode.getGameID(), gamemode);
    }
}
